# km2miles

`km2miles` is a simple Python package to convert kilometers to miles.

## Installation
You can install this package via pip (after publishing to PyPI):

```bash
pip install km2miles
